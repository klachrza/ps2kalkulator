/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0xef153c89 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Designs/klawa_/klawa_/wysw.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_2873092032_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    int t12;
    char *t13;
    int t14;
    char *t15;
    int t17;
    char *t18;
    int t20;
    char *t21;
    int t23;
    char *t24;
    int t26;
    char *t27;
    int t29;
    char *t30;
    int t32;
    char *t33;
    int t35;
    char *t36;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;

LAB0:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 528U);
    t2 = ieee_p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2216);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(32, ng0);
    t3 = (t0 + 1252U);
    t4 = *((char **)t3);
    t5 = *((int *)t4);
    t6 = (t5 + 1);
    t3 = (t0 + 2260);
    t7 = (t3 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((int *)t10) = t6;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(33, ng0);
    t1 = (t0 + 1252U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t2 = (t5 == 1);
    if (t2 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1252U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t1 = (t0 + 1428U);
    t4 = *((char **)t1);
    t6 = *((int *)t4);
    t12 = (10 * t6);
    t2 = (t5 == t12);
    if (t2 != 0)
        goto LAB33;

LAB34:    t1 = (t0 + 1252U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t1 = (t0 + 1428U);
    t4 = *((char **)t1);
    t6 = *((int *)t4);
    t12 = (20 * t6);
    t2 = (t5 == t12);
    if (t2 != 0)
        goto LAB60;

LAB61:    t1 = (t0 + 1252U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t1 = (t0 + 1428U);
    t4 = *((char **)t1);
    t6 = *((int *)t4);
    t12 = (30 * t6);
    t2 = (t5 == t12);
    if (t2 != 0)
        goto LAB87;

LAB88:    t1 = (t0 + 1252U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t1 = (t0 + 1428U);
    t4 = *((char **)t1);
    t6 = *((int *)t4);
    t12 = (40 * t6);
    t2 = (t5 == t12);
    if (t2 != 0)
        goto LAB114;

LAB115:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(34, ng0);
    t1 = (t0 + 3776);
    t7 = (t0 + 2296);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 812U);
    t3 = *((char **)t1);
    t1 = (t0 + 3780);
    t5 = xsi_mem_cmp(t1, t3, 8U);
    if (t5 == 1)
        goto LAB9;

LAB21:    t7 = (t0 + 3788);
    t6 = xsi_mem_cmp(t7, t3, 8U);
    if (t6 == 1)
        goto LAB10;

LAB22:    t9 = (t0 + 3796);
    t12 = xsi_mem_cmp(t9, t3, 8U);
    if (t12 == 1)
        goto LAB11;

LAB23:    t11 = (t0 + 3804);
    t14 = xsi_mem_cmp(t11, t3, 8U);
    if (t14 == 1)
        goto LAB12;

LAB24:    t15 = (t0 + 3812);
    t17 = xsi_mem_cmp(t15, t3, 8U);
    if (t17 == 1)
        goto LAB13;

LAB25:    t18 = (t0 + 3820);
    t20 = xsi_mem_cmp(t18, t3, 8U);
    if (t20 == 1)
        goto LAB14;

LAB26:    t21 = (t0 + 3828);
    t23 = xsi_mem_cmp(t21, t3, 8U);
    if (t23 == 1)
        goto LAB15;

LAB27:    t24 = (t0 + 3836);
    t26 = xsi_mem_cmp(t24, t3, 8U);
    if (t26 == 1)
        goto LAB16;

LAB28:    t27 = (t0 + 3844);
    t29 = xsi_mem_cmp(t27, t3, 8U);
    if (t29 == 1)
        goto LAB17;

LAB29:    t30 = (t0 + 3852);
    t32 = xsi_mem_cmp(t30, t3, 8U);
    if (t32 == 1)
        goto LAB18;

LAB30:    t33 = (t0 + 3860);
    t35 = xsi_mem_cmp(t33, t3, 8U);
    if (t35 == 1)
        goto LAB19;

LAB31:
LAB20:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 3938);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);

LAB8:    goto LAB6;

LAB9:    xsi_set_current_line(37, ng0);
    t36 = (t0 + 3868);
    t38 = (t0 + 2332);
    t39 = (t38 + 32U);
    t40 = *((char **)t39);
    t41 = (t40 + 40U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 7U);
    xsi_driver_first_trans_fast_port(t38);
    goto LAB8;

LAB10:    xsi_set_current_line(38, ng0);
    t1 = (t0 + 3875);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB11:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 3882);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB12:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 3889);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB13:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 3896);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB14:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 3903);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB15:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 3910);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB16:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 3917);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB17:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 3924);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB18:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 3931);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB19:    xsi_set_current_line(47, ng0);
    goto LAB8;

LAB32:;
LAB33:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 3945);
    t8 = (t0 + 2296);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 900U);
    t3 = *((char **)t1);
    t1 = (t0 + 3949);
    t5 = xsi_mem_cmp(t1, t3, 8U);
    if (t5 == 1)
        goto LAB36;

LAB48:    t7 = (t0 + 3957);
    t6 = xsi_mem_cmp(t7, t3, 8U);
    if (t6 == 1)
        goto LAB37;

LAB49:    t9 = (t0 + 3965);
    t12 = xsi_mem_cmp(t9, t3, 8U);
    if (t12 == 1)
        goto LAB38;

LAB50:    t11 = (t0 + 3973);
    t14 = xsi_mem_cmp(t11, t3, 8U);
    if (t14 == 1)
        goto LAB39;

LAB51:    t15 = (t0 + 3981);
    t17 = xsi_mem_cmp(t15, t3, 8U);
    if (t17 == 1)
        goto LAB40;

LAB52:    t18 = (t0 + 3989);
    t20 = xsi_mem_cmp(t18, t3, 8U);
    if (t20 == 1)
        goto LAB41;

LAB53:    t21 = (t0 + 3997);
    t23 = xsi_mem_cmp(t21, t3, 8U);
    if (t23 == 1)
        goto LAB42;

LAB54:    t24 = (t0 + 4005);
    t26 = xsi_mem_cmp(t24, t3, 8U);
    if (t26 == 1)
        goto LAB43;

LAB55:    t27 = (t0 + 4013);
    t29 = xsi_mem_cmp(t27, t3, 8U);
    if (t29 == 1)
        goto LAB44;

LAB56:    t30 = (t0 + 4021);
    t32 = xsi_mem_cmp(t30, t3, 8U);
    if (t32 == 1)
        goto LAB45;

LAB57:    t33 = (t0 + 4029);
    t35 = xsi_mem_cmp(t33, t3, 8U);
    if (t35 == 1)
        goto LAB46;

LAB58:
LAB47:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 4107);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);

LAB35:    goto LAB6;

LAB36:    xsi_set_current_line(54, ng0);
    t36 = (t0 + 4037);
    t38 = (t0 + 2332);
    t39 = (t38 + 32U);
    t40 = *((char **)t39);
    t41 = (t40 + 40U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 7U);
    xsi_driver_first_trans_fast_port(t38);
    goto LAB35;

LAB37:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 4044);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB38:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 4051);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB39:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 4058);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB40:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 4065);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB41:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 4072);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB42:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 4079);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB43:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 4086);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB44:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 4093);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB45:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 4100);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB35;

LAB46:    xsi_set_current_line(64, ng0);
    goto LAB35;

LAB59:;
LAB60:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 4114);
    t8 = (t0 + 2296);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 988U);
    t3 = *((char **)t1);
    t1 = (t0 + 4118);
    t5 = xsi_mem_cmp(t1, t3, 8U);
    if (t5 == 1)
        goto LAB63;

LAB75:    t7 = (t0 + 4126);
    t6 = xsi_mem_cmp(t7, t3, 8U);
    if (t6 == 1)
        goto LAB64;

LAB76:    t9 = (t0 + 4134);
    t12 = xsi_mem_cmp(t9, t3, 8U);
    if (t12 == 1)
        goto LAB65;

LAB77:    t11 = (t0 + 4142);
    t14 = xsi_mem_cmp(t11, t3, 8U);
    if (t14 == 1)
        goto LAB66;

LAB78:    t15 = (t0 + 4150);
    t17 = xsi_mem_cmp(t15, t3, 8U);
    if (t17 == 1)
        goto LAB67;

LAB79:    t18 = (t0 + 4158);
    t20 = xsi_mem_cmp(t18, t3, 8U);
    if (t20 == 1)
        goto LAB68;

LAB80:    t21 = (t0 + 4166);
    t23 = xsi_mem_cmp(t21, t3, 8U);
    if (t23 == 1)
        goto LAB69;

LAB81:    t24 = (t0 + 4174);
    t26 = xsi_mem_cmp(t24, t3, 8U);
    if (t26 == 1)
        goto LAB70;

LAB82:    t27 = (t0 + 4182);
    t29 = xsi_mem_cmp(t27, t3, 8U);
    if (t29 == 1)
        goto LAB71;

LAB83:    t30 = (t0 + 4190);
    t32 = xsi_mem_cmp(t30, t3, 8U);
    if (t32 == 1)
        goto LAB72;

LAB84:    t33 = (t0 + 4198);
    t35 = xsi_mem_cmp(t33, t3, 8U);
    if (t35 == 1)
        goto LAB73;

LAB85:
LAB74:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 4276);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);

LAB62:    goto LAB6;

LAB63:    xsi_set_current_line(71, ng0);
    t36 = (t0 + 4206);
    t38 = (t0 + 2332);
    t39 = (t38 + 32U);
    t40 = *((char **)t39);
    t41 = (t40 + 40U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 7U);
    xsi_driver_first_trans_fast_port(t38);
    goto LAB62;

LAB64:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 4213);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB65:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 4220);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB66:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 4227);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB67:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 4234);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB68:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4241);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB69:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4248);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB70:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 4255);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB71:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 4262);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB72:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 4269);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB62;

LAB73:    xsi_set_current_line(81, ng0);
    goto LAB62;

LAB86:;
LAB87:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 4283);
    t8 = (t0 + 2296);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1076U);
    t3 = *((char **)t1);
    t1 = (t0 + 4287);
    t5 = xsi_mem_cmp(t1, t3, 8U);
    if (t5 == 1)
        goto LAB90;

LAB102:    t7 = (t0 + 4295);
    t6 = xsi_mem_cmp(t7, t3, 8U);
    if (t6 == 1)
        goto LAB91;

LAB103:    t9 = (t0 + 4303);
    t12 = xsi_mem_cmp(t9, t3, 8U);
    if (t12 == 1)
        goto LAB92;

LAB104:    t11 = (t0 + 4311);
    t14 = xsi_mem_cmp(t11, t3, 8U);
    if (t14 == 1)
        goto LAB93;

LAB105:    t15 = (t0 + 4319);
    t17 = xsi_mem_cmp(t15, t3, 8U);
    if (t17 == 1)
        goto LAB94;

LAB106:    t18 = (t0 + 4327);
    t20 = xsi_mem_cmp(t18, t3, 8U);
    if (t20 == 1)
        goto LAB95;

LAB107:    t21 = (t0 + 4335);
    t23 = xsi_mem_cmp(t21, t3, 8U);
    if (t23 == 1)
        goto LAB96;

LAB108:    t24 = (t0 + 4343);
    t26 = xsi_mem_cmp(t24, t3, 8U);
    if (t26 == 1)
        goto LAB97;

LAB109:    t27 = (t0 + 4351);
    t29 = xsi_mem_cmp(t27, t3, 8U);
    if (t29 == 1)
        goto LAB98;

LAB110:    t30 = (t0 + 4359);
    t32 = xsi_mem_cmp(t30, t3, 8U);
    if (t32 == 1)
        goto LAB99;

LAB111:    t33 = (t0 + 4367);
    t35 = xsi_mem_cmp(t33, t3, 8U);
    if (t35 == 1)
        goto LAB100;

LAB112:
LAB101:    xsi_set_current_line(99, ng0);
    t1 = (t0 + 4445);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);

LAB89:    goto LAB6;

LAB90:    xsi_set_current_line(88, ng0);
    t36 = (t0 + 4375);
    t38 = (t0 + 2332);
    t39 = (t38 + 32U);
    t40 = *((char **)t39);
    t41 = (t40 + 40U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 7U);
    xsi_driver_first_trans_fast_port(t38);
    goto LAB89;

LAB91:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 4382);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB92:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 4389);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB93:    xsi_set_current_line(91, ng0);
    t1 = (t0 + 4396);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB94:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 4403);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB95:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4410);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB96:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 4417);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB97:    xsi_set_current_line(95, ng0);
    t1 = (t0 + 4424);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB98:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 4431);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB99:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 4438);
    t4 = (t0 + 2332);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB89;

LAB100:    xsi_set_current_line(98, ng0);
    goto LAB89;

LAB113:;
LAB114:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 2260);
    t7 = (t1 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((int *)t10) = 0;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

}


extern void work_a_2873092032_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2873092032_3212880686_p_0};
	xsi_register_didat("work_a_2873092032_3212880686", "isim/_tmp/work/a_2873092032_3212880686.didat");
	xsi_register_executes(pe);
}
