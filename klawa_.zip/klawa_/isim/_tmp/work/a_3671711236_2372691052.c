/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0xef153c89 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Designs/klawa_/klawa_/tb.vhd";



static void work_a_3671711236_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 2204U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2548);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 1504U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 2120);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(119, ng0);
    t2 = (t0 + 2548);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(120, ng0);
    t2 = (t0 + 1504U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 2120);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_3671711236_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int t8;
    int t9;
    char *t10;
    char *t11;
    int t12;
    int t13;
    int t14;
    int t15;
    unsigned int t16;
    unsigned int t17;
    int t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int64 t27;

LAB0:    t1 = (t0 + 2332U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(130, ng0);
    t2 = (t0 + 2584);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(131, ng0);
    t7 = (100 * 1000000LL);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(132, ng0);
    t2 = (t0 + 2584);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(133, ng0);
    t7 = (200 * 1000000LL);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(140, ng0);
    t2 = (t0 + 5004);
    *((int *)t2) = 0;
    t3 = (t0 + 5008);
    *((int *)t3) = 20;
    t8 = 0;
    t9 = 20;

LAB12:    if (t8 <= t9)
        goto LAB13;

LAB15:    xsi_set_current_line(167, ng0);
    t2 = (t0 + 5020);
    *((int *)t2) = 0;
    t3 = (t0 + 5024);
    *((int *)t3) = 20;
    t8 = 0;
    t9 = 20;

LAB52:    if (t8 <= t9)
        goto LAB53;

LAB55:    xsi_set_current_line(194, ng0);
    t2 = (t0 + 5036);
    *((int *)t2) = 0;
    t3 = (t0 + 5040);
    *((int *)t3) = 20;
    t8 = 0;
    t9 = 20;

LAB92:    if (t8 <= t9)
        goto LAB93;

LAB95:    xsi_set_current_line(221, ng0);

LAB134:    *((char **)t1) = &&LAB135;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB13:    xsi_set_current_line(141, ng0);
    t4 = (t0 + 2620);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    t10 = (t6 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(142, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB14:    t2 = (t0 + 5004);
    t8 = *((int *)t2);
    t3 = (t0 + 5008);
    t9 = *((int *)t3);
    t12 = (t8 + 1);
    t8 = t12;
    t4 = (t0 + 5004);
    *((int *)t4) = t8;
    goto LAB12;

LAB16:    xsi_set_current_line(143, ng0);
    t2 = (t0 + 5012);
    *((int *)t2) = 0;
    t3 = (t0 + 5016);
    *((int *)t3) = 7;
    t12 = 0;
    t13 = 7;

LAB20:    if (t12 <= t13)
        goto LAB21;

LAB23:    xsi_set_current_line(153, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(154, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB34:    *((char **)t1) = &&LAB35;
    goto LAB1;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

LAB21:    xsi_set_current_line(144, ng0);
    t4 = (t0 + 2620);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    t10 = (t6 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(145, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB26:    *((char **)t1) = &&LAB27;
    goto LAB1;

LAB22:    t2 = (t0 + 5012);
    t12 = *((int *)t2);
    t3 = (t0 + 5016);
    t13 = *((int *)t3);
    t14 = (t12 + 1);
    t12 = t14;
    t4 = (t0 + 5012);
    *((int *)t4) = t12;
    goto LAB20;

LAB24:    xsi_set_current_line(146, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(148, ng0);
    t2 = (t0 + 1164U);
    t3 = *((char **)t2);
    t2 = (t0 + 5012);
    t14 = *((int *)t2);
    t15 = (t14 - 7);
    t16 = (t15 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, *((int *)t2));
    t17 = (1U * t16);
    t4 = (t0 + 5004);
    t18 = *((int *)t4);
    t19 = (t18 - 0);
    t20 = (t19 * 1);
    xsi_vhdl_check_range_of_index(0, 21, 1, *((int *)t4));
    t21 = (8U * t20);
    t22 = (0 + t21);
    t23 = (t22 + t17);
    t5 = (t3 + t23);
    t24 = *((unsigned char *)t5);
    t6 = (t0 + 2656);
    t10 = (t6 + 32U);
    t11 = *((char **)t10);
    t25 = (t11 + 40U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t24;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(149, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB30:    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB25:    goto LAB24;

LAB27:    goto LAB25;

LAB28:    goto LAB22;

LAB29:    goto LAB28;

LAB31:    goto LAB29;

LAB32:    xsi_set_current_line(155, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB38:    *((char **)t1) = &&LAB39;
    goto LAB1;

LAB33:    goto LAB32;

LAB35:    goto LAB33;

LAB36:    xsi_set_current_line(157, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(158, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB42:    *((char **)t1) = &&LAB43;
    goto LAB1;

LAB37:    goto LAB36;

LAB39:    goto LAB37;

LAB40:    xsi_set_current_line(159, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(160, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB46:    *((char **)t1) = &&LAB47;
    goto LAB1;

LAB41:    goto LAB40;

LAB43:    goto LAB41;

LAB44:    xsi_set_current_line(161, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(163, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t27 = (t7 * 3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t27);

LAB50:    *((char **)t1) = &&LAB51;
    goto LAB1;

LAB45:    goto LAB44;

LAB47:    goto LAB45;

LAB48:    goto LAB14;

LAB49:    goto LAB48;

LAB51:    goto LAB49;

LAB53:    xsi_set_current_line(168, ng0);
    t4 = (t0 + 2620);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    t10 = (t6 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(169, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB58:    *((char **)t1) = &&LAB59;
    goto LAB1;

LAB54:    t2 = (t0 + 5020);
    t8 = *((int *)t2);
    t3 = (t0 + 5024);
    t9 = *((int *)t3);
    t12 = (t8 + 1);
    t8 = t12;
    t4 = (t0 + 5020);
    *((int *)t4) = t8;
    goto LAB52;

LAB56:    xsi_set_current_line(170, ng0);
    t2 = (t0 + 5028);
    *((int *)t2) = 0;
    t3 = (t0 + 5032);
    *((int *)t3) = 7;
    t12 = 0;
    t13 = 7;

LAB60:    if (t12 <= t13)
        goto LAB61;

LAB63:    xsi_set_current_line(180, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(181, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB74:    *((char **)t1) = &&LAB75;
    goto LAB1;

LAB57:    goto LAB56;

LAB59:    goto LAB57;

LAB61:    xsi_set_current_line(171, ng0);
    t4 = (t0 + 2620);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    t10 = (t6 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(172, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB66:    *((char **)t1) = &&LAB67;
    goto LAB1;

LAB62:    t2 = (t0 + 5028);
    t12 = *((int *)t2);
    t3 = (t0 + 5032);
    t13 = *((int *)t3);
    t14 = (t12 + 1);
    t12 = t14;
    t4 = (t0 + 5028);
    *((int *)t4) = t12;
    goto LAB60;

LAB64:    xsi_set_current_line(173, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(175, ng0);
    t2 = (t0 + 1252U);
    t3 = *((char **)t2);
    t2 = (t0 + 5028);
    t14 = *((int *)t2);
    t15 = (t14 - 7);
    t16 = (t15 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, *((int *)t2));
    t17 = (1U * t16);
    t4 = (t0 + 5020);
    t18 = *((int *)t4);
    t19 = (t18 - 0);
    t20 = (t19 * 1);
    xsi_vhdl_check_range_of_index(0, 21, 1, *((int *)t4));
    t21 = (8U * t20);
    t22 = (0 + t21);
    t23 = (t22 + t17);
    t5 = (t3 + t23);
    t24 = *((unsigned char *)t5);
    t6 = (t0 + 2656);
    t10 = (t6 + 32U);
    t11 = *((char **)t10);
    t25 = (t11 + 40U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t24;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(176, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB70:    *((char **)t1) = &&LAB71;
    goto LAB1;

LAB65:    goto LAB64;

LAB67:    goto LAB65;

LAB68:    goto LAB62;

LAB69:    goto LAB68;

LAB71:    goto LAB69;

LAB72:    xsi_set_current_line(182, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(183, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB78:    *((char **)t1) = &&LAB79;
    goto LAB1;

LAB73:    goto LAB72;

LAB75:    goto LAB73;

LAB76:    xsi_set_current_line(184, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(185, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB82:    *((char **)t1) = &&LAB83;
    goto LAB1;

LAB77:    goto LAB76;

LAB79:    goto LAB77;

LAB80:    xsi_set_current_line(186, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(187, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB86:    *((char **)t1) = &&LAB87;
    goto LAB1;

LAB81:    goto LAB80;

LAB83:    goto LAB81;

LAB84:    xsi_set_current_line(188, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(190, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t27 = (t7 * 3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t27);

LAB90:    *((char **)t1) = &&LAB91;
    goto LAB1;

LAB85:    goto LAB84;

LAB87:    goto LAB85;

LAB88:    goto LAB54;

LAB89:    goto LAB88;

LAB91:    goto LAB89;

LAB93:    xsi_set_current_line(195, ng0);
    t4 = (t0 + 2620);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    t10 = (t6 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(196, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB98:    *((char **)t1) = &&LAB99;
    goto LAB1;

LAB94:    t2 = (t0 + 5036);
    t8 = *((int *)t2);
    t3 = (t0 + 5040);
    t9 = *((int *)t3);
    t12 = (t8 + 1);
    t8 = t12;
    t4 = (t0 + 5036);
    *((int *)t4) = t8;
    goto LAB92;

LAB96:    xsi_set_current_line(197, ng0);
    t2 = (t0 + 5044);
    *((int *)t2) = 0;
    t3 = (t0 + 5048);
    *((int *)t3) = 7;
    t12 = 0;
    t13 = 7;

LAB100:    if (t12 <= t13)
        goto LAB101;

LAB103:    xsi_set_current_line(207, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(208, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB114:    *((char **)t1) = &&LAB115;
    goto LAB1;

LAB97:    goto LAB96;

LAB99:    goto LAB97;

LAB101:    xsi_set_current_line(198, ng0);
    t4 = (t0 + 2620);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    t10 = (t6 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(199, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB106:    *((char **)t1) = &&LAB107;
    goto LAB1;

LAB102:    t2 = (t0 + 5044);
    t12 = *((int *)t2);
    t3 = (t0 + 5048);
    t13 = *((int *)t3);
    t14 = (t12 + 1);
    t12 = t14;
    t4 = (t0 + 5044);
    *((int *)t4) = t12;
    goto LAB100;

LAB104:    xsi_set_current_line(200, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(202, ng0);
    t2 = (t0 + 1340U);
    t3 = *((char **)t2);
    t2 = (t0 + 5044);
    t14 = *((int *)t2);
    t15 = (t14 - 7);
    t16 = (t15 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, *((int *)t2));
    t17 = (1U * t16);
    t4 = (t0 + 5036);
    t18 = *((int *)t4);
    t19 = (t18 - 0);
    t20 = (t19 * 1);
    xsi_vhdl_check_range_of_index(0, 21, 1, *((int *)t4));
    t21 = (8U * t20);
    t22 = (0 + t21);
    t23 = (t22 + t17);
    t5 = (t3 + t23);
    t24 = *((unsigned char *)t5);
    t6 = (t0 + 2656);
    t10 = (t6 + 32U);
    t11 = *((char **)t10);
    t25 = (t11 + 40U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t24;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(203, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB110:    *((char **)t1) = &&LAB111;
    goto LAB1;

LAB105:    goto LAB104;

LAB107:    goto LAB105;

LAB108:    goto LAB102;

LAB109:    goto LAB108;

LAB111:    goto LAB109;

LAB112:    xsi_set_current_line(209, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(210, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB118:    *((char **)t1) = &&LAB119;
    goto LAB1;

LAB113:    goto LAB112;

LAB115:    goto LAB113;

LAB116:    xsi_set_current_line(211, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(212, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB122:    *((char **)t1) = &&LAB123;
    goto LAB1;

LAB117:    goto LAB116;

LAB119:    goto LAB117;

LAB120:    xsi_set_current_line(213, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(214, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t7);

LAB126:    *((char **)t1) = &&LAB127;
    goto LAB1;

LAB121:    goto LAB120;

LAB123:    goto LAB121;

LAB124:    xsi_set_current_line(215, ng0);
    t2 = (t0 + 2620);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(217, ng0);
    t2 = (t0 + 1568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t27 = (t7 * 3);
    t2 = (t0 + 2248);
    xsi_process_wait(t2, t27);

LAB130:    *((char **)t1) = &&LAB131;
    goto LAB1;

LAB125:    goto LAB124;

LAB127:    goto LAB125;

LAB128:    goto LAB94;

LAB129:    goto LAB128;

LAB131:    goto LAB129;

LAB132:    goto LAB2;

LAB133:    goto LAB132;

LAB135:    goto LAB133;

}


extern void work_a_3671711236_2372691052_init()
{
	static char *pe[] = {(void *)work_a_3671711236_2372691052_p_0,(void *)work_a_3671711236_2372691052_p_1};
	xsi_register_didat("work_a_3671711236_2372691052", "isim/_tmp/work/a_3671711236_2372691052.didat");
	xsi_register_executes(pe);
}
